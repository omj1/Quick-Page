<?php
$nazwa_firmy = "Nazwa Twojej Firmy";
$ulica = "Przeskok 3/6";
$kod = "05-822";
$miasto = "Twoje Miasto";
$telefon = "22  456 78 99";
$komorka = "53 342 344 44";
$fax = "21 234 56 09";
$email = "biuro@twoja-firma.pl";

?>