<?php
require_once 'kontrolery/kontrolery.php';
require_once 'kontrolery/menu.php';
require_once 'szablony/'.$szablon.'/index.php';
?>
