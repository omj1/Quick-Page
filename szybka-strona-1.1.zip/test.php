<?php
echo $_SERVER['SERVER_NAME'];
echo '<br>';
echo $_SERVER['PHP_SELF'];
?>
