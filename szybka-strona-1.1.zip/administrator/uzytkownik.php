<?php
// plik 
$loginplik = "admin";
$hasloplik = "21232f297a57a5a743894a0e4a801fc3";

?>