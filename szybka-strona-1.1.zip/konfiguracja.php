<?php
// plik 
$title = "Szybka strona";
$description = "Opis działalności";
$keywords = "Słowa kluczowe";
$szablon = "biznes-bialy";
$backgroundimage = "nie";

?>